// CoursePage.js
import { useState } from "react";
import CourseContent from "../Components/CourseContent/CourseContent";
import LessonViewer from "../Components/CourseContent/LessonViewer";

const CoursePage = ({ course }) => {
  const [selectedLesson, setSelectedLesson] = useState(null);

  return (
    <div className="flex flex-col md:flex-row gap-6 px-4 py-6">
      <div className="md:w-1/3">
        <CourseContent course={course} onSelectLesson={setSelectedLesson} />
      </div>
      <div className="md:w-2/3">
        <LessonViewer lesson={selectedLesson} />
      </div>
    </div>
  );
};

export default CoursePage;
